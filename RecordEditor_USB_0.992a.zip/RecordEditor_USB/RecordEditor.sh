#! /bin/sh
    
    java -jar "lib/runFullEditor.jar" ${@}

 
