#! /bin/sh
    
    java -jar "lib/runCsvEditor.jar" ${@}

 
