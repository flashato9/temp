#! /bin/sh

    ##libdir=/home/bm/RecordEdit/HSQLDB/lib

    java -jar run.jar net.sf.RecordEditor.edit.util.RunVelocityGui

