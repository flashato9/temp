#! /bin/sh

    #libdir=%INSTALL_PATH/lib

    ##cd ../Database
    ##%JAVA_HOME/bin/java -cp "${libdir}/LayoutEdit.jar:${libdir}/hsqldbmain.jar:${libdir}/RecordEdit.jar" net.sf.RecordEditor.layoutEd.ShutdownHSQLDB
    java -jar run.jar net.sf.RecordEditor.layoutEd.ShutdownHSQLDB

 
