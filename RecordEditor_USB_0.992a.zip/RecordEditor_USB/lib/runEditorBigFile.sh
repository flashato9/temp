#! /bin/sh

    ##libdir=/home/bm/RecordEdit/Generic/lib
    
    java -Xmx1500m -jar runFullEditor.jar ${@}

 
