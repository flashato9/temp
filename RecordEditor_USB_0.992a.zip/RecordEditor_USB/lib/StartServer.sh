#! /bin/sh

    cd ../Database

    java -cp ../lib/hsqldbmain.jar org.hsqldb.Server

 
