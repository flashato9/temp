#! /bin/sh
   
    java -jar RunCobolEditor.jar ${@}

 
