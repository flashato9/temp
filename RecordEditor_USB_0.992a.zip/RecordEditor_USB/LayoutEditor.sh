#! /bin/sh
   
   java -jar "lib/runLayouteditor.jar" 
